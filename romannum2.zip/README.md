# Roman-numeral-parser
A quick node script that validates and parses roman numerals

Usage 

`npm init`

`node . VI`
